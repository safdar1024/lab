/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author sali.bscs13seecs
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({lab10.fileObjectPojoTest.class, lab10.Lab10Test.class, lab10.applicationTest.class})
public class Lab10Suite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
}
