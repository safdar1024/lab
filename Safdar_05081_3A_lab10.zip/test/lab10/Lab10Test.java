/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import java.io.File;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sali.bscs13seecs
 */
public class Lab10Test {
    
    public Lab10Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of sha1 method, of class Lab10.
     */
    @Test
    public void testSha1() throws Exception {
        System.out.println("sha1");
        File folder = new File("C:\\Users\\sali.bscs13seecs\\Desktop\\directory");
    File[] listOfFiles = folder.listFiles();

        String expResult = "aefjdkafj34343kfjadkf";
        String result = Lab10.sha1(listOfFiles[0]);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of main method, of class Lab10.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        Lab10.main(args);
        
        fail("The test case is a prototype.");
    }
    
}
