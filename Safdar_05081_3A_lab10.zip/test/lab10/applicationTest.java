/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sali.bscs13seecs
 */
public class applicationTest {
    
    public applicationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of main method, of class application.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        application.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addfileObjectPojo method, of class application.
     */
    @Test
    public void testAddfileObjectPojo() {
        System.out.println("sha1");
        File folder = new File("C:\\Users\\sali.bscs13seecs\\Desktop\\directory");
    File[] listOfFiles = folder.listFiles();

        String expResult = "aefjdkafj34343kfjadkf";
        String result="";
        try {
            result = Lab10.sha1(listOfFiles[0]);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(applicationTest.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(applicationTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of retrievefileObjectPojos method, of class application.
     */
    @Test
    public void testRetrievefileObjectPojos() {
        System.out.println("retrievefileObjectPojos");
        String s = "";
        application instance = new application();
        instance.retrievefileObjectPojos(s);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of SetupPassiveMonotoring method, of class application.
     */
    @Test
    public void testSetupPassiveMonotoring() {
        System.out.println("SetupPassiveMonotoring");
        application ME = null;
        application instance = new application();
        instance.SetupPassiveMonotoring(ME);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
