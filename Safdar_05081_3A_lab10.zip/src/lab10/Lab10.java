/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sali.bscs13seecs
 */
public class Lab10 {

  public static  HashMap<File , String> hm = new HashMap<File, String>();
    /**
     * @param args the command line arguments
     */
     public static String sha1(final File file) throws NoSuchAlgorithmException, IOException {
    final MessageDigest messageDigest = MessageDigest.getInstance("SHA1");

    try (InputStream is = new BufferedInputStream(new FileInputStream(file))) {
      final byte[] buffer = new byte[1024];
      for (int read = 0; (read = is.read(buffer)) != -1;) {
        messageDigest.update(buffer, 0, read);
      }
    }

    // Convert the byte to hex format
    try (Formatter formatter = new Formatter()) {
      for (final byte b : messageDigest.digest()) {
        formatter.format("%02x", b);
      }
      return formatter.toString();
    }
  }
    
     
     
     
    public static void main(String[] args) throws NoSuchAlgorithmException {
        // TODO code application logic here
       //calculate the hashmap of all the file objects and storin in map 
    File folder = new File("C:\\Users\\sali.bscs13seecs\\Desktop\\directory");
    File[] listOfFiles = folder.listFiles();

    for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        System.out.println("File " + listOfFiles[i].getName());
      } else if (listOfFiles[i].isDirectory()) {
        System.out.println("Directory " + listOfFiles[i].getName());
      }
    }   
         
         

         try {  
          for (int i = 0; i < listOfFiles.length; i++) {   
        hm.put(listOfFiles[i],sha1(listOfFiles[i]) );
        System.out.println(hm.get(listOfFiles[i]));
          
          }
             
             
         } catch (Exception ex) {
             Logger.getLogger(Lab10.class.getName()).log(Level.SEVERE, null, ex);
         }
         
        
    }
    
}
