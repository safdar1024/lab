/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

/**
 *
 * @author sali.bscs13seecs
 */
    public class fileObjectPojo {
    
   
   private int id;
   private String fileName; 
   private String hashValue;   
  
   public fileObjectPojo() {}
   public fileObjectPojo(String fname, String lname) {
      this.fileName = fname;
      this.hashValue = lname;
    }
   public int getId() {
      return id;
   }
   public void setId( int id ) {
      this.id = id;
   }
   public String getFileName() {
      return fileName;
   }
   public void setFileName( String file_name ) {
      this.fileName = file_name;
   }
   public String getHashValue() {
      return hashValue;
   }
   public void setHashValue( String hashValue_n ) {
      this.hashValue = hashValue_n;
   }
}
